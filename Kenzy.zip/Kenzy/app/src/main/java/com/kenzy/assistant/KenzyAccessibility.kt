package com.kenzy.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class KenzyAccessibility : AccessibilityService() {
    companion object { var instance: KenzyAccessibility? = null }
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    fun clickText(text: String): Boolean {
        val node = rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.firstOrNull() ?: return false
        var n: android.view.accessibility.AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable) return n.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }
}
