package com.kenzy.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Panneau façon Siri qui apparaît en bas de l'écran. */
class Overlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var tv: TextView? = null
    private var pulse: ValueAnimator? = null
    private val hideRun = Runnable { hide() }

    fun show(text: String, hideAfterMs: Long) {
        h.removeCallbacks(hideRun)
        if (root == null) build()
        tv?.text = text
        h.postDelayed(hideRun, hideAfterMs)
    }

    private fun build() {
        if (!Settings.canDrawOverlays(ctx)) return
        val d = ctx.resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()

        val orb = View(ctx).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = dp(30).toFloat()
                colors = intArrayOf(0xFFFF4D4D.toInt(), 0xFF8A0010.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply { bottomMargin = dp(10) }
        }
        val label = TextView(ctx).apply {
            text = "KENZY"; textSize = 12f; setTextColor(0xFFB3001B.toInt()); letterSpacing = 0.3f
            gravity = Gravity.CENTER
        }
        val t = TextView(ctx).apply {
            textSize = 20f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        val panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(0xF2120606.toInt())
                setStroke(dp(2), 0xFFB3001B.toInt())
            }
            addView(orb); addView(label); addView(t)
            setOnClickListener { hide() }
        }
        val frame = FrameLayout(ctx).apply {
            setPadding(dp(12), 0, dp(12), dp(24))
            addView(panel)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }
        try { wm.addView(frame, lp) } catch (e: Exception) { return }
        root = frame; tv = t
        pulse = ValueAnimator.ofFloat(1f, 1.3f).apply {
            duration = 700; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { orb.scaleX = it.animatedValue as Float; orb.scaleY = it.animatedValue as Float }
            start()
        }
    }

    fun hide() {
        h.removeCallbacks(hideRun)
        pulse?.cancel(); pulse = null
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; tv = null
    }
}
