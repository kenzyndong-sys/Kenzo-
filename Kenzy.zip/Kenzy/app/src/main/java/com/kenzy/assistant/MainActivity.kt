package com.kenzy.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var b1: Button
    private lateinit var b2: Button
    private lateinit var b3: Button
    private lateinit var go: Button
    private var running = false

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun style(b: Button, main: Boolean) {
        b.setTextColor(Color.WHITE); b.isAllCaps = false; b.textSize = 16f
        b.background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(if (main) 0xFFB3001B.toInt() else 0xFF1E1212.toInt())
            if (!main) setStroke(dp(1), 0xFF4A1A1A.toInt())
        }
        b.layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.BLACK); setPadding(dp(28), dp(56), dp(28), dp(28))
        }
        l.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(120))
        })
        l.addView(TextView(this).apply {
            text = "Kenzy"; textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        })
        l.addView(TextView(this).apply {
            text = "Dis simplement « Kenzy »"; textSize = 15f; setTextColor(0xFF999999.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(24))
        })
        b1 = Button(this).also { style(it, false); l.addView(it) }
        b2 = Button(this).also { style(it, false); l.addView(it) }
        b3 = Button(this).also { style(it, false); l.addView(it) }
        go = Button(this).also { style(it, true); (it.layoutParams as LinearLayout.LayoutParams).topMargin = dp(28); l.addView(it) }

        b1.setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1) }
        b2.setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        b3.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        go.setOnClickListener {
            if (running) stopService(Intent(this, KenzyService::class.java))
            else startForegroundService(Intent(this, KenzyService::class.java))
            running = !running; refresh()
        }
        setContentView(l)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val ov = Settings.canDrawOverlays(this)
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
        b1.text = (if (mic) "✓ " else "") + "Micro et notifications"
        b2.text = (if (ov) "✓ " else "") + "Affichage par-dessus"
        b3.text = (if (acc) "✓ " else "") + "Accessibilité (facultatif)"
        go.text = if (running) "Arrêter Kenzy" else "Démarrer Kenzy"
        go.isEnabled = mic && ov
        go.alpha = if (go.isEnabled) 1f else 0.4f
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); refresh()
    }
}
