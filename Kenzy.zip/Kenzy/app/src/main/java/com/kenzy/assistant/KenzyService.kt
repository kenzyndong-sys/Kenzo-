package com.kenzy.assistant

import android.app.*
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class KenzyService : Service(), RecognitionListener {
    private var rec: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var overlay: Overlay
    private val h = Handler(Looper.getMainLooper())
    private var awaitingUntil = 0L
    private val wake = Regex("\\b(kenzy|kenzie|kenzi|quenzy|kensi|kenzy's)\\b")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("kenzy", "Kenzy", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif("Dites « Kenzy »"))
        overlay = Overlay(this)
        tts = TextToSpeech(this) { tts.language = Locale.FRENCH }
        listen()
    }

    private fun notif(txt: String): Notification =
        Notification.Builder(this, "kenzy").setContentTitle("Kenzy écoute")
            .setContentText(txt).setSmallIcon(android.R.drawable.ic_btn_speak_now).build()

    private fun status(txt: String) =
        getSystemService(NotificationManager::class.java).notify(1, notif(txt))

    private fun listen() {
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(this)
            it.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR"))
        }
    }

    override fun onPartialResults(p: Bundle?) {
        if (System.currentTimeMillis() < awaitingUntil) {
            val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            if (t.isNotEmpty()) overlay.show(t, 9000)
        }
    }

    override fun onResults(r: Bundle?) {
        val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: ""
        if (text.isNotEmpty()) status("J'ai entendu : $text")
        val m = wake.find(text)
        val now = System.currentTimeMillis()
        val cmd = when {
            m != null -> text.substring(m.range.last + 1).trim()
            now < awaitingUntil -> text.trim()
            else -> null
        }
        if (cmd != null) {
            if (cmd.isEmpty()) {
                awaitingUntil = now + 9000
                try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 120) } catch (_: Exception) {}
                overlay.show("Je vous écoute…", 9000)
            } else {
                awaitingUntil = 0
                val reply = CommandHandler.run(this, cmd)
                overlay.show("« $cmd »\n$reply", 2500)
                tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "k")
            }
        }
        h.postDelayed({ listen() }, 150)
    }

    override fun onError(e: Int) {
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) status("Micro non autorisé")
        else if (e != SpeechRecognizer.ERROR_NO_MATCH && e != SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
            status("Erreur reconnaissance ($e)")
        h.postDelayed({ listen() }, 500)
    }

    override fun onDestroy() { rec?.destroy(); tts.shutdown(); overlay.hide() }

    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(t: Int, p: Bundle?) {}
}
